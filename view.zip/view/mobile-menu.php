<!-- Start Mobile-menu -->
			<div class="mobile-menu-area hidden-md hidden-lg">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<nav id="mobile-menu">
								<ul>
									<li><a href="index.php">Home</a>
										<ul>
											<li><a href="index.php">Home Page 1</a></li>
											<li><a href="index.php">Home Page 2</a></li>
										</ul>
									</li>
									<li><a href="about.php">About Us</a></li>
									<li><a href="shop.php">Bestseller Products</a></li>
									<li><a href="shop-list.php">New Products</a></li>
									<li><a href="#">Pages</a>
										<ul>
											<li><a href="cart.php">Cart</a></li>
											<li><a href="checkout.php">Checkout</a></li>
											<li><a href="account.php">Create Account</a></li>
											<li><a href="login.php">Login</a></li>
											<li><a href="my-account.php">My Account</a></li>
											<li><a href="product-details.php">Product details</a></li>
											<li><a href="shop.php">Shop Grid View</a></li>
											<li><a href="shop-list.php">Shop List View</a></li>
											<li><a href="wishlist.php">Wish List</a></li>
										</ul>
									</li>
									<li><a href="contact.php">Contact Us</a></li>
								</ul>
							</nav>
						</div>
					</div>
				</div>
			</div>
			<!-- End Mobile-menu -->
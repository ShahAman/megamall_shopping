<?php 
require_once("control/control.php");
?>
<div class="left-category-menu hidden-sm hidden-xs">
           <div class="left-product-cat">
               <div class="category-heading">
                   <h2>My Menus</h2>
               </div>
               <div class="category-menu-list">
                   <ul>
					<div class="cat-left-drop-menu">
					   <div class="cat-left-drop-menu-left">
						   <ul><li><a href="">Account Details</a></li></ul>
						   <ul><li><a href="">Addresses</a></li></ul>
						   <ul><li><a href="">Orders</a></li></ul>
					   </div>
					   
					</div>
					<?php 
					
						//$category = $control->get_data("category");
					?>
                       <!-- MENU MENU -->
						
                       <!--<li class="arrow-plus">
                           <a href="shop.php">Cameras & Photography</a>
							
                           <div class="cat-left-drop-menu">
                               <div class="cat-left-drop-menu-left">
                                   <ul>
                                       <li><a href="#">Blouses And Shirts</a></li>
                                       <li><a href="#">Clutches</a></li>
                                   </ul>
                               </div>
                               
                           </div>
							
                       </li>-->
						
						<!-- MENU MENU -->
                       
                       <!--<li class=" rx-parent">
                           <a class="rx-default">
                               More categories <span class="cat-thumb  fa fa-plus"></span> 
                           </a>
                           <a class="rx-show">
                               close menu <span class="cat-thumb  fa fa-minus"></span>
                           </a>
                       </li>-->
                       <!-- MENU ACCORDION END -->
                   </ul>
               </div>
           </div>
       </div>
<!-- START MAINMENU-AREA -->
			<div class="mainmenu-area">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="mainmenu hidden-sm hidden-xs">
								<nav>
									<ul>
										<li><a href="index.php">Home</a>
											<ul>
												<li><a href="index.php">Home Versions 1</a></li>
												<li><a href="index.php">Home Versions 2</a></li>
											</ul>
										</li>
										<li><a href="about.php">About Us</a></li>
										<li class="hot"><a href="shop.php">Featured Products</a></li>
										<li class="new"><a href="shop-list.php">Latest Products</a></li>
										<li><a href="shop.php">Special Products</a></li>
										<li><a href="#">Pages</a>
											<ul>
												<li><a href="cart.php">Cart</a></li>
												<li><a href="checkout.php">Checkout</a></li>
												<li><a href="account.php">Create Account</a></li>
												<li><a href="my-account.php">My Account</a></li>
												<li><a href="product-details.php">Product details</a></li>
												<li><a href="shop.php">Shop Grid View</a></li>
												<li><a href="shop-list.php">Shop List View</a></li>
												<li><a href="wishlist.php">Wish List</a></li>
											</ul>
										</li>
										<li><a href="contact.php">Contact Us</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN-MENU-AREA -->